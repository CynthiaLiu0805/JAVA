
public class addToArray {

	
	public static void main(String []args) {
		double [] randomNumbers = new double[4];
		int MAX = 10;
		int i;
		for (i = 0; i < randomNumbers.length; i++) {
			randomNumbers[i] = Math.random()*MAX;
			System.out.println(randomNumbers[i]);
		}
		randomNumbers[i]= addValue(5) ;
		System.out.println(randomNumbers[i]);
	}
	
	public static double addValue(double n) {
		return Math.random()*n;
	}
}
