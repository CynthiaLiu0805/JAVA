
public class scope {

	String first = "Hello ";
	static String second = "World";

	public static void main(String[] args) {
		String first = "Hey ";
		changeName();
		System.out.println(first + second);
	}
	
	public static void changeName() {
		String first = "Bonjour ";
		second = "friend";
	}
}
