/*********************************************************************
 * Compilation: javac Harmonic.java* Execution: java Harmonic n* * Prints the
 * nth harmonic number: 1/1 + 1/2 + ... + 1/n.* * % java Harmonic 10*
 * 2.9289682539682538** % java Harmonic 10000* 9.787606036044348
 **********************************************************************/
public class Harmonic {
	// returns 1/1 + 1/2 + 1/3 + ... + 1/n
	public static double harmonic(int n) {
		// sum of 1/1 + 1/2 + 1/3 + ... + 1/n
		double sum = 0.0;
		for (int i = 0; i < n; i++) {
			sum = sum + (1.0/(i+1));
		}
		// your code here
		return sum;
	}

	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
			int arg = Integer.parseInt(args[i]);
			// call the harmonic method and store the return value into a double called value
			double value = harmonic(arg);
			// your code here
			StdOut.println(value);
		}
	}
}
