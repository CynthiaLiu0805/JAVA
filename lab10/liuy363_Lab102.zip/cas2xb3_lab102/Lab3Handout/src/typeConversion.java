
public class typeConversion {

	public static void main(String[] args) {
		String inputNumber = "938.32";
		double doubleNumber = Double.parseDouble(inputNumber);
		int integerNumber = (int) doubleNumber;		
	}
}

