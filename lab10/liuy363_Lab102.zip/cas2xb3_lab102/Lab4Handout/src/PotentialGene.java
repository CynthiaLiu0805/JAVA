/*****************************************************************************
 * Compilation: javac PotentialGene.java* Execution: java PotentialGene <
 * input.txt* Determines whether a a DNA string corresponds to a potential gene
 * -length is a multiple of 3 -starts with the start codon (ATG) -ends with a
 * stop codon (TAA or TAG or TGA) -has no intervening stop codons(i.e. a stop
 * codon cannot be in the middle of the string.* % java PotentialGene
 * ATGCGCCTGCGTCTGTACTAG true* % java PotentialGene ATGCGCTGCGTCTGTACTAG false
 *****************************************************************************/
public class PotentialGene {
	public static boolean isPotentialGene(String dna) {
		// Your code here
		// Length is a multiple of 3.
		if (dna.length() % 3 == 0) {
			String[] dnaParts = new String[dna.length() / 3];
			for (int i = 0; i < dna.length() / 3; i++) {
				dnaParts[i] = dna.substring(i * 3, i * 3 + 3);
				System.out.println(dnaParts[i]);
			}
			// Starts with start codon.ATG
			if (dnaParts[0].equalsIgnoreCase("atg")) {
				// No intervening stop codons.
				
				String stopCond = "TAA TAG TGA";
				for (int i = 1; i < dnaParts.length-1; i++) {
					if (stopCond.contains(dnaParts[i].toUpperCase())) {
						return false;
					}
					
				}// Ends with a stop codon. TAA or TAG or TGA
				if(stopCond.contains(dnaParts[dnaParts.length-1].toUpperCase())) {
					return true;
				}
				
			}
		}

		return false;
	}

	public static void main(String[] args) {
		String dna = args[0];
		System.out.println(isPotentialGene(dna));
	}

}
