
public class javaQuizQuestions {

	
	
	
	public static void main(String[] args) {
		
		int a = 4;
		float b = 8;
		double c = 12.0;
		
		//System.out.println(a*b/c);
		question2();
		}
	
	public static void question2() {
		double[] list = new double[4];
		for (int i = 0; i < 5; i++) {
			list[i] = i;
			System.out.println(list[i]);
		}
	}
}
