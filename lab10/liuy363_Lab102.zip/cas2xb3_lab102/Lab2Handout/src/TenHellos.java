public class TenHellos {
	public static void main(String[] args) {
		// print out special cases whose ordinal doesn't end in
		// System.out.println("1st Hello");
		// System.out.println("2nd Hello");
		// System.out.println("3rd Hello");
// count from i = 4 to 10
		int i = 1;
		int first = 0;
		int second = 10;
		int third = 9;
		while (i <= 10) {
			if (first == 0) {
				System.out.println(i + "st Hello");
			} else if (second == 0) {
				System.out.println(i + "nd Hello");
			} else if (third == 0) {
				System.out.println(i + "rd Hello");
			} else
				System.out.println(i + "th Hello");
			i = i + 1;
			if (first == 10) {
				first = 0;
			}
			first = first + 1;
			if (second == 10) {
				second = 0;
			}
			second = second + 1;
			if (third == 10) {
				third = 0;
			}
			third = third + 1;
		}
	}
}