package cas2xb3_A2_Liu_CL;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testcases {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}





//
//public static void writeToFile(String s) {
//	try{
//		FileWriter f = new FileWriter("output.txt", true);
//		f.write(s + "\n");
//		f.close();
//	}
//	catch(Exception e){
//		e.printStackTrace();
//	}
//}