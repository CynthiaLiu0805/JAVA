import java.io.BufferedInputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

public class Job implements Comparable<Job>{

	private final String jobName;
	private final double processingTime;

	public int compareTo(Job that)// compare processing times of tow jobs and returns 0 (equal), -1(this greater
									// than that) and 1 (that greater than this
	{
		if (this.processingTime < that.processingTime)
			return -1;
		if (this.processingTime > that.processingTime)
			return 1;
		return 0;
	}

	public String toString()// convert the job name and processing time to a String value
	{
		return String.format("%s %.1f", jobName, processingTime);
	}

	public String getJobName() {
		return jobName;
	}

	public double getProcessingTime() {
		return processingTime;
	}

	public Job(String jobName, double processingTime) {
		if (processingTime < 0)
			throw new IllegalArgumentException();
		this.jobName = jobName;
		this.processingTime = processingTime;
	}

	public static void main(String[] args) {
		Scanner input = new Scanner(new BufferedInputStream(System.in));
		PrintWriter output = new PrintWriter(new OutputStreamWriter(System.out), true);
		int size = input.nextInt();
		Job[] jobs = new Job[size];
		for (int i = 0; i < size; i++) {
			String jobName = input.next();
			double jobDuration = input.nextDouble();
			jobs[i] = new Job(jobName, jobDuration);
		}
		//Arrays.sort(jobs);
		//SelectionSort.sort((Comparable[])jobs);
		//BubbleSort.sort((Comparable[])jobs);
		ShellSort.sort((Comparable[])jobs);
		output.println();
		output.println("sorted jobs");
		for (int i = 0; i < size; i++)
			output.print(jobs[i] + " ");
		output.println();
		String[] a = {"a","b"};
		System.out.println(a);
	}
	
	
	public void test() {
		
		//String b = a.toS
	}
}
