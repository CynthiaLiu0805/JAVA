import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ShellSortTest {
	//ArrayList<Job> globaljobs = new ArrayList<Job>();
	Job[] globaljobs1 = new Job[18];
	Job[] globaljobs2 = new Job[18];
	@Before
	public void setUp() throws Exception {
		Scanner input;
		FileWriter f;
		Job[] jobs = new Job[18];
		//ArrayList<Job> jobs = new ArrayList<Job>();
		int i = 0;
		try {
			input = new Scanner(new File("data/input.txt"));
			//f = new FileWriter("data/output.txt");
			while (input.hasNext()) {
				String current = input.next();
				String[] tempString = current.split(",");
				Job temp = new Job(tempString[0], Double.parseDouble(tempString[1]));
				globaljobs1[i] = temp;
				globaljobs2[i] = temp;
				//jobs[i] = temp;
				//jobs.add(temp);
				//f.write(temp.toString() + "\n");
				System.out.println("New Job added  = " + temp);
				//System.out.println("dist(p, temp) = " + p.distTo(temp));
				i++;
			}
			input.close();
			//f.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//globaljobs1 = jobs;
		//globaljobs2 = jobs;
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSort() {
		//ShellSort.sort((Comparable[])globaljobs.toArray());
		//boolean isSorted = ShellSort.isSorted((Comparable[])globaljobs.toArray());
		Job[] ShellSortjobs = globaljobs1;
		Job[] SelectionSortjobs = globaljobs2;
		//ShellSort.sort(ShellSortjobs);
		ShellSort.sort(SelectionSortjobs);
		boolean isSorted = ShellSort.isSorted(globaljobs1);
		assertTrue(isSorted);
		//assertTrue(SelectionSort.isSorted(SelectionSortjobs));
	}

}
