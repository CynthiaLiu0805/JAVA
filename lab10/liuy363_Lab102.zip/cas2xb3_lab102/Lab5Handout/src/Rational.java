
public class Rational {
	private final int numerator;
	private final int denominator;

	public int getNumerator() {
		return this.numerator;
	}

	public int getDenominator() {
		return this.denominator;
	}

	public Rational(int numerator, int denominator) {

		int g = gcd(numerator, denominator);
		this.numerator = numerator / g;
		this.denominator = denominator / g;
	}

	public Rational(long numerator, long denominator) {
		// include int overflow exception
		int g = gcd((int) numerator, (int) denominator);
		this.numerator = (int) numerator / g;
		this.denominator = (int) denominator / g;
	}

	private int gcd(int n, int d) {
		while (d != 0) {
			int temp = d;
			d = n % d;
			n = temp;
		}
		return n;
	}

	public Rational plus(Rational b) {
		return new Rational(this.getNumerator() * b.getDenominator() + b.getNumerator() * this.getDenominator(),
				this.denominator * b.denominator);
	}

	public Rational minus(Rational b) {
		return new Rational(this.getNumerator() * b.getDenominator() - b.getNumerator() * this.getDenominator(),
				this.denominator * b.denominator);
	}

	public Rational multiply(Rational b) {
		return new Rational(this.getNumerator() * b.getNumerator(), this.getDenominator() * b.getDenominator());
	}

	public Rational divide(Rational b) {
		return new Rational(this.getNumerator() * b.getDenominator(), this.getDenominator() * b.getNumerator());
	}

	public boolean equals(Rational that) {
		if (this.getNumerator() == that.getNumerator() && this.getDenominator() == that.getDenominator()) {
			return true;
		}
		return false;
	}
	public String toString() {
		return this.getNumerator() + "/" + this.getDenominator();
	}
	
	public static void main(String [] args) {
		Rational x = new Rational(5,4);
		Rational y = new Rational(1,4);
		
		Rational z = x.divide(y);
		System.out.println(z.toString());
	}

}
