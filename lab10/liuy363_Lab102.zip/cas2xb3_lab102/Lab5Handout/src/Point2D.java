import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Point2D {
	private final double x;
	private final double y;

	Point2D(double x, double y) {
		this.x = x;
		this.y = y;
	}

	Point2D() {
		this.x = 0.0;
		this.y = 0.0;
	}

	public double x() {
		return x;
	}

	double y() {
		return this.y;
	}

	double r() {
		return Math.sqrt(this.x * this.x + this.y * this.y);
	}

	double theta() {
		return Math.atan2(this.y, this.x);
	}

	double distTo(Point2D that) {
		return Math.sqrt(Math.pow(this.x - that.x, 2) + Math.pow(this.y - that.y, 2));
	}

	public String toString() {
		return "(" + x() + "," + y() + ")";
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Point2D p = new Point2D();
		System.out.println("p  = " + p);
		System.out.println("   x     = " + p.x());
		System.out.println("   y     = " + p.y());
		System.out.println("   r     = " + p.r());
		System.out.println("   theta = " + p.theta());
		System.out.println();
		Point2D q = new Point2D(0.5, 0.5);
		System.out.println("q  = " + q);
		System.out.println("dist(p, q) = " + p.distTo(q));

		Scanner input;
		FileWriter f;
		try {
			input = new Scanner(new File("data/input.txt"));
			f = new FileWriter("outputData/output.txt");
			while (input.hasNext()) {
				String current = input.next();
				String[] tempString = current.split(",");
				Point2D temp = new Point2D(Double.parseDouble(tempString[0]), Double.parseDouble(tempString[1]));
				
				f.write(temp.toString() + "\n");
				//System.out.println("New point  = " + temp);
				//System.out.println("dist(p, temp) = " + p.distTo(temp));
			}
			input.close();
			f.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		
		
		
	}

}
