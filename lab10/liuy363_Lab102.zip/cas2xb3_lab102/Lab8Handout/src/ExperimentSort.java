import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Random;

public class ExperimentSort {

	private static Job[] unsortedJobs(int N) {
		int size = N;// input.nextInt();
		Job[] jobs = new Job[size];
		for (int i = 0; i < size; i++) {
			Random random = new Random();
			Integer newNumber = new Integer(random.nextInt(10000));
			String jobName = "Job " + i;
			double jobDuration = newNumber;
			jobs[i] = new Job(jobName, jobDuration);
		}
		return jobs;
	}

	public static void main(String[] args) {

		int[] x = { 10, 100, 1000, 10000, 100000, 1000000};
		double[] ySelection = new double[x.length];
		double[] yBubble = new double[x.length];
		double[] yShell = new double[x.length];
		for (int i = 0; i < x.length; i++) {
			// SelectionSortTime
			Stopwatch stopwatch = new Stopwatch();
			double startTime = stopwatch.elapsedTime();
			//SelectionSort.sort((Comparable[]) unsortedJobs(x[i]));
			double endTime = stopwatch.elapsedTime();
			ySelection[i] = endTime - startTime;
			System.out.println("Executing SelectionSort for N = " + x[i]);
			System.out.println("Total execution time: " + (endTime - startTime));
			// BubbleSortTime
			stopwatch = new Stopwatch();
			startTime = stopwatch.elapsedTime();
			//BubbleSort.sort((Comparable[]) unsortedJobs(x[i]));
			endTime = stopwatch.elapsedTime();
			yBubble[i] = endTime - startTime;
			System.out.println("Executing BubbleSort for N = " + x[i]);
			System.out.println("Total execution time: " + (endTime - startTime));
			// ShellSortTime
			stopwatch = new Stopwatch();
			startTime = stopwatch.elapsedTime();
			ShellSort.sort((Comparable[]) unsortedJobs(x[i]));
			endTime = stopwatch.elapsedTime();
			yShell[i] = endTime - startTime;
			System.out.println("Executing ShellSort for N = " + x[i]);
			System.out.println("Total execution time: " + (endTime - startTime));
		}

		// Arrays.sort(jobs);
		
		
		

		StdDraw.setXscale(-1000, 100500);
		StdDraw.setYscale(-1000, 30000);
		StdDraw.line(-100, 0, 100500, 0); // x-axis
		StdDraw.line(0, -100, 0, 30000); // y-axis
		double scale = 1000;
		for (int i = 0; i < x.length-1; i++) {
			StdDraw.setPenColor(StdDraw.RED);
			StdDraw.line(x[i], scale*ySelection[i], x[i + 1], scale*ySelection[i + 1]);
			StdDraw.setPenColor(StdDraw.BLUE);
			StdDraw.line(x[i], scale*yBubble[i], x[i + 1], scale*yBubble[i + 1]);
			StdDraw.setPenColor(StdDraw.GREEN);
			StdDraw.line(x[i], scale*yShell[i], x[i + 1], scale*yShell[i + 1]);
		}
//		output.println();
//		output.println("sorted jobs");
//		for (int i = 0; i < size; i++)
//			output.print(jobs[i] + " ");
//		output.println();
	}
}
