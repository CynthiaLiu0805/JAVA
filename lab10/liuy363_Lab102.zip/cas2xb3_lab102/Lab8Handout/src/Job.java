import java.io.BufferedInputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Job implements Comparable<Job> {

	private final String jobName;
	private final double processingTime;

	public int compareTo(Job that)// compare processing times of tow jobs and returns 0 (equal), -1(this greater
									// than that) and 1 (that greater than this
	{
		if (this.processingTime < that.processingTime)
			return -1;
		if (this.processingTime > that.processingTime)
			return 1;
		return 0;
	}

	public String toString()// convert the job name and processing time to a String value
	{
		return String.format("%s %.1f", jobName, processingTime);
	}

	public String getJobName() {
		return jobName;
	}

	public double getProcessingTime() {
		return processingTime;
	}

	public Job(String jobName, double processingTime) {
		if (processingTime < 0)
			throw new IllegalArgumentException();
		this.jobName = jobName;
		this.processingTime = processingTime;
	}
}
