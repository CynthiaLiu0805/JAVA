import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * 
 */

/**
 * @author Gabriel
 *
 */
class MoneyTest {

	private Money f12CAD;
	private Money f14CAD;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		f12CAD = new Money(12,"CAD");
		f14CAD = new Money(14,"CAD");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link Money#add(Money)}.
	 */
	@Test
	void testAdd() {
		Money expected = new Money(26,"CAD");
		Money result = f12CAD.add(f14CAD);
		assertTrue(expected.equals(result));
	}

	/**
	 * Test method for {@link Money#equals(java.lang.Object)}.
	 */
	@Test
	void testEqualsObject() {
		assertTrue(!f12CAD.equals(null));
		assertTrue(!f12CAD.equals(f14CAD));
		assertFalse(f12CAD.equals(f14CAD));
		assertEquals(f12CAD, f12CAD);
		assertEquals(f12CAD, new Money(12,"CAD"));
	}

}
