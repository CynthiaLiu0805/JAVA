/*Student Information*-------------------* 
 * Student Name: Liu, Cynthia* 
 * Student Number: 400172720* 
 * Course Code: CS/SE 2XB3
 * * Lab Section: 02* * 
 * I attest that the following code being submitted is my own individual work.*/


import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;

class exceedLengthException extends Exception {

    public exceedLengthException(String message) {
        super(message);
    }
}
class notUnitStringException extends Exception {

    public notUnitStringException(String message) {
        super(message);
    }
}

class testSet {
	static Set s1;
	static Set s2;
	static Set s3;
	static Set s4;
	static Set s5;
	static Set s6;
	public testSet() {
		File file = new File("input.txt");
	    try {
	        Scanner sc = new Scanner(file);
            String string1 = sc.nextLine();
            String string2 = sc.nextLine();
            String string3 = sc.nextLine();
            String string4 = sc.nextLine();
            s1 = new Set(string1.split(","));  //a,b,c
			s2 = new Set(string2.split(","));  //d,e,f,a
			s3 = new Set(string3.split(","));  //d,e,f,g,h,i
			s4 = new Set(string4.split(",")); //a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s
	        sc.close();
	    } 
	    catch (FileNotFoundException e) {
	        e.printStackTrace();
	    }
	 }
	

	public static void writeToFile(String s) {
		try{
			FileWriter f = new FileWriter("output.txt", true);
			f.write(s + "\n");
			f.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public static void main(String [] args) throws exceedLengthException,notUnitStringException {
	
		testSet beginTest=new testSet();
		testUnion();

		testAdd();
		System.out.print("test add pass");
		System.out.println();

		testDel();
		System.out.print("test del pass");
		System.out.println();

		System.out.print("test union pass");
        System.out.println();

		testIntersection();
		System.out.print("test intersection pass");
        System.out.println();

		testDifference();
		System.out.print("test difference pass");
        System.out.println();
        
        testProduct();
        System.out.print("test product pass");
        System.out.println();
        
        testIsEqual();
		System.out.print("test isEqual pass");
        System.out.println();
        
        testIsSubset();
		System.out.print("test isSubset pass");
        System.out.println();

		testGetCount();
		System.out.print("test getCount pass");
        System.out.println();
        
        testToString();
		System.out.print("test ToString pass");
        System.out.println();
	}
	


	public static void testAdd() throws exceedLengthException,notUnitStringException {
		String [] expected1= {"a","b","c"};
		Set expectedSet1=new Set(expected1);
		Set result1 = s1.add("a");
		if (result1.isEqual(expectedSet1)) {
			writeToFile("testAdd1 pass");
		} else {
			writeToFile("testAdd1 fail");
		}

		String [] expected2= {"a","b","c","g"};
		Set expectedSet2=new Set(expected2);
		Set result2 = s1.add("g");
		if (result2.isEqual(expectedSet2)) {
			writeToFile("testAdd2 pass");
		} else {
			writeToFile("testAdd2 fail");
		}
	}


	public static void testDel() throws exceedLengthException,notUnitStringException {
		String [] expected1= {"a","b","c"};
		Set expectedSet1=new Set(expected1);
		Set result1 = s1.del("g");
		if (result1.isEqual(expectedSet1)) {
			writeToFile("testDel1 pass");
		} else {
			writeToFile("testDel1 fail");
		}

		String [] expected2= {"b","c"};
		Set expectedSet2=new Set(expected2);
		Set result2 = s1.del("a");
		if (result2.isEqual(expectedSet2)) {
			writeToFile("testDel2 pass");
		} else {
			writeToFile("testDel2 fail");
		}
	}
	
	

	public static void testUnion() throws exceedLengthException,notUnitStringException {
        String [] expected1= {"a","b","c","d","e","f"};
        Set expectedSet1=new Set(expected1);
        Set result1 = s1.set_union(s2);
		if (result1.isEqual(expectedSet1)) {
			writeToFile("testUnion1 pass");
		} else {
			writeToFile("testUnion1 fail");
		}
		
        String [] expected2= {"a","b","c","d","e","f","g","h","i"};
        Set expectedSet2=new Set(expected2);
        Set result2 = s1.set_union(s3);
        if (result2.isEqual(expectedSet2)) {
			writeToFile("testUnion2 pass");
		} else {
			writeToFile("testUnion2 fail");
		}
	}
	
	public static void testIntersection() throws exceedLengthException,notUnitStringException {
		String [] expected1= {};
        Set expectedSet1=new Set(expected1);
        Set result1 = s1.set_intersection(s3);
        if (result1.isEqual(expectedSet1)) {
			writeToFile("testIntersection1 pass");
		} else {
			writeToFile("testIntersection1 fail");
		}
		
        String [] expected2= {"d","e","f"};
        Set expectedSet2=new Set(expected2);
        Set result2 = s2.set_intersection(s3);
        if (result2.isEqual(expectedSet2)) {
			writeToFile("testIntersection2 pass");
		} else {
			writeToFile("testIntersection2 fail");
		}		
		String [] expected3= {"a","b","c"};
        Set expectedSet3=new Set(expected3);
        Set result3 = s1.set_intersection(s4);
        if (result3.isEqual(expectedSet3)) {
			writeToFile("testIntersection3 pass");
		} else {
			writeToFile("testIntersection3 fail");
		}	}
	
	public static void testDifference() throws exceedLengthException,notUnitStringException {
		String [] expected1= {"g","h","i"};
        Set expectedSet1=new Set(expected1);
        Set result1 = s3.set_difference(s2);
        if (result1.isEqual(expectedSet1)) {
			writeToFile("testDifference1 pass");
		} else {
			writeToFile("testDifference1 fail");
		}

        String [] expected2= {"d","e","f"};
        Set expectedSet2=new Set(expected2);
        Set result2 = s2.set_difference(s1);
        if (result2.isEqual(expectedSet2)) {
			writeToFile("testDifference2 pass");
		} else {
			writeToFile("testDifference2 fail");
		}		
	}
	
	public static void testProduct() throws exceedLengthException,notUnitStringException {
		String [] expected1= {"aa", "ab", "ac", "ba", "bb", "bc", "ca", "cb", "cc"};
        Set expectedSet1=new Set(expected1);
        Set result1 = s1.set_product(s1);
        if (result1.isEqual(expectedSet1)) {
			writeToFile("testProduct1 pass");
		} else {
			writeToFile("testProduct1 fail");
		}
        String [] expected2= {"da", "db", "dc", "ea", "eb", "ec", "fa", "fb", "fc", "aa", "ab", "ac"};
        Set expectedSet2=new Set(expected2);
        Set result2 = s2.set_product(s1);
        if (result2.isEqual(expectedSet2)) {
			writeToFile("testProduct2 pass");
		} else {
			writeToFile("testProduct2 fail");
		}
	}
	
	
	public static void testIsEqual() throws exceedLengthException,notUnitStringException {
		String [] expected1= {"a","b","c","d","e","f"};
        Set expectedSet1=new Set(expected1);
        Set result1 = s1.set_union(s2);
        if (result1.isEqual(expectedSet1)) {
			writeToFile("testIsEqual1 pass");
		} else {
			writeToFile("testIsEqual1 fail");
		}
        String [] expected2= {"d","e","f"};
        Set expectedSet2=new Set(expected2);
        Set result2 = s2.set_difference(s1);
        if (result2.isEqual(expectedSet2)) {
			writeToFile("testIsEqual2 pass");
		} else {
			writeToFile("testIsEqual2 fail");
		}

	}
	
	public static void testIsSubset() throws exceedLengthException,notUnitStringException {
		if (s3.isSubset(s4)) {
			writeToFile("testIsSubset1 pass");
		} else {
			writeToFile("testIsSubset1 fail");
		}
		if (!s2.isSubset(s3)) {
			writeToFile("testIsSubset2 pass");
		} else {
			writeToFile("testIsSubset2 fail");
		}	
	}
	
	public static void testGetCount() throws exceedLengthException,notUnitStringException  {
        int result1 = s1.getCount();
        if (result1==3) {
			writeToFile("testGetCount1 pass");
		} else {
			writeToFile("testGetCount1 fail");
		}
        int result2 = s4.set_union(s3).getCount();
        if (result2==19) {
			writeToFile("testGetCount2 pass");
		} else {
			writeToFile("testGetCount2 fail");
		}
	}
	
	public static void testToString() throws exceedLengthException,notUnitStringException  {
		String expected1= "{a, b, c}";
        String result1 = s1.toString();
        if (result1.equals(expected1)) {
        	writeToFile("testToString1 pass");
        } else {
        	writeToFile("testToString2 fail");
        }
	}
}
