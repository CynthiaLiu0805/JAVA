/*Student Information*-------------------* 
 * Student Name: Liu, Cynthia* 
 * Student Number: 400172720* 
 * Course Code: CS/SE 2XB3
 * * Lab Section: 02* * 
 * I attest that the following code being submitted is my own individual work.*/


import java.util.*;

public class Set{


    //return a arraylist of elements
    public List<String> get_set(){
        List<String> result = new ArrayList<>();
        for (int i=0;i<this.myarray.length;i++) {
            result.add(myarray[i]);
        }
        return result;
    }

    public boolean check_unit(String [] input) {
        for (int i=0;i<input.length;i++) {
            if (input[i].length()!=1) {
                return false;
            }
        }
        return true;
    }



    String [] myarray = new String[20];
    public Set(String [] array) {
          this.myarray = array;
    }


    //add a new element to the set
    public Set add(String s) {
        List<String> arrlist = new ArrayList<String>(Arrays.asList(myarray));
        if (!arrlist.contains(s)) {
            arrlist.add(s);
        }

        Object [] newSet = arrlist.toArray();
        String[] finalset = Arrays.copyOf(newSet, newSet.length, String[].class);
        Set finalSet=new Set(finalset);
        return finalSet;
    }

    //del an element in the set
    public Set del(String s) {
        List<String> arrlist = new ArrayList<String>(Arrays.asList(myarray));
        if (arrlist.contains(s)) {
            arrlist.remove(s);
        }

        Object [] newSet = arrlist.toArray();
        String[] finalset = Arrays.copyOf(newSet, newSet.length, String[].class);
        Set finalSet=new Set(finalset);
        return finalSet;
    }
    
    //return the union of two sets
    public Set set_union(Set R){
        List<String> arrlist = new ArrayList<String>(Arrays.asList(myarray));
        String[] arr2 = R.myarray;
		for (String str:arr2){
			if (!arrlist.contains(str)) {
				arrlist.add(str);
			}
        }
        Object [] newSet = arrlist.toArray();
        String[] finalset = Arrays.copyOf(newSet, newSet.length, String[].class);
        Set finalSet=new Set(finalset);
        return finalSet;
    }

    //return the intersection of two sets
    public Set set_intersection(Set R) {
        List<String> arrlist = new ArrayList<String>(Arrays.asList(myarray));
        String[] arr2 = R.myarray;
        List<String> finalarrlist = new ArrayList();
        for (String str:arr2){
            if (arrlist.contains(str)) {
                finalarrlist.add(str);
            }
        }
        Object [] newSet = finalarrlist.toArray();
        String[] finalset = Arrays.copyOf(newSet, newSet.length, String[].class);
        Set finalSet=new Set(finalset);
        return finalSet;
    }



    //return the difference of two sets
    //the elements in this set but not that set(R-S)
    public Set set_difference(Set R) {
        List<String> thisArrlist = new ArrayList<String>(Arrays.asList(myarray));
        String[] arr2 = R.myarray;
        List<String> thatArrlist = new ArrayList<String>(Arrays.asList(arr2));
        List<String> finalarrlist = new ArrayList();
        for (String str:thisArrlist){  //for element in this set
            if (!thatArrlist.contains(str)) {  //if it in not in that set
                finalarrlist.add(str);
            }
        }
        Object [] newSet = finalarrlist.toArray();
        String[] finalset = Arrays.copyOf(newSet, newSet.length, String[].class);
        Set finalSet=new Set(finalset);
        return finalSet;
    }



    //Return the Cartesian product (cross product) of this set by another set (i.e. R  Χ S,
    // the set of all possible pairs of concatenated elements of the form rs where r in R and s in S
    public Set set_product(Set R) {
        List<String> thisArrlist = new ArrayList<String>(Arrays.asList(myarray));
        String[] arr2 = R.myarray;
        List<String> thatArrlist = new ArrayList<String>(Arrays.asList(arr2));
        List<String> finalarrlist = new ArrayList();
        for (String str1 : thisArrlist) {  //for element in this set
            for (String str2 : thatArrlist) {  //element in that set
                finalarrlist.add(str1 + str2);
            }
        }
        Object[] newSet = finalarrlist.toArray();
        String[] finalset = Arrays.copyOf(newSet, newSet.length, String[].class);
        Set finalSet = new Set(finalset);
        return finalSet;
    }

    //are these sets equal? Return Boolean.Remember,sets are reflexive, symmetric, and transitive.
    // By definition, a set cannot have duplicate element
    public boolean isEqual(Set R) {
        List<String> arrlist1 = new ArrayList<String>(Arrays.asList(myarray));
        String[] arr2 = R.myarray;
        List<String> arrlist2 = new ArrayList<String>(Arrays.asList(arr2));

        List<String> finalarrlist = new ArrayList();
        for (String str : arrlist1) {  //check arrlist1
            if (!arrlist2.contains(str)) {  //if it in not in that set
                return false;
            }
        }
        for (String str : arrlist2) {  //check arrlist2
            if (!arrlist1.contains(str)) {  //if it in not in that set
                return false;
            }
        }
        return true;
    }



    //return if a set is subset of another set
    // every element in S is in R, this set is myarray
    public boolean isSubset(Set R) {
        List<String> arrlist = R.get_set();
        for (int i=0;i<myarray.length;i++) {
            if (!arrlist.contains(myarray[i])) {
                return false;
            }
        }
        return true;
    }


    //return the number of elements in a set
    public int getCount() {
        int counter=0;
        for (int i=0;i<myarray.length;i++) {
            if (myarray[i] != null) {
                counter++;
            }

        }
        return counter;
    }

    //only return a sting
    public String toString(){
        List<String> result = new ArrayList<>();
        for (int i=0;i<this.myarray.length;i++) {
            result.add(myarray[i]);
        }
        return "{"+String.valueOf(result).subSequence(1, String.valueOf(result).length()-1)+"}";
    }


}